package PageObjectModel;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginTest {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//Create object of LoginPage
		//LoginPage LoginPg = new LoginPage(driver);
		LoginPage2 LoginPg = new LoginPage2(driver);  //--Login page 2 
		
		//Open URL
		driver.get("https://www.saucedemo.com/");
		
		LoginPg.enterUsername("standard_user");
		LoginPg.enterPassword("secret_sauce");
		
		LoginPg.clickOnLoginBtn();
		

	}

}
