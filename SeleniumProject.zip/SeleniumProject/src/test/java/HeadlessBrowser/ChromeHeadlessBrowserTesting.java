package HeadlessBrowser;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ChromeHeadlessBrowserTesting {

	public static void main(String[] args) {

		WebDriverManager .chromedriver().setup();

		//headless browser below method are used
		ChromeOptions options = new ChromeOptions();
		options.setHeadless(true);

		WebDriver driver = new ChromeDriver(options);

		driver.manage().window().maximize();

		//Open Url
		driver.get("https://www.google.com/");

		//Print title of the Web page
		System.out.println("Before Search:" + driver.getTitle());

		//Search browser find
		WebElement searchBox= driver.findElement(By.name("q"));
		searchBox.sendKeys("India Gate");
		searchBox.sendKeys(Keys.ENTER);

		//Print title of the Web page
		System.out.println("After Search:" + driver.getTitle());

		//Pause of 3 sec.
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver.quit();
	}

}
