package CrossBrowserTesting;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CrossBrowserTesting {


	WebDriver driver;

	@BeforeMethod
	@Parameters("browser")
	public void LaunchBrowser(String browser) {

		switch(browser.toLowerCase())
		{
		case "chrome":
			//WebDriverManager.chromedriver().setup();
			WebDriver driver = new ChromeDriver();
			driver =new ChromeDriver();
			break;

		case "msedge":
			//WebDriverManager.edgedriver().setup();
			WebDriver driver1 = new EdgeDriver();
			driver1 =new EdgeDriver();
			break;
			
			default:
				driver1 = null;
				break;
		}
	}

	@Test
	public void VerifyTitle() {

		driver.get("https://www.google.com/");
		String ExpectedTitle = "Google";
		String ActualTitle = driver.getTitle();
		Assert.assertEquals(ExpectedTitle, ActualTitle);

	}

	@AfterMethod
	public void Quit() {

		driver.quit();
	}
}
