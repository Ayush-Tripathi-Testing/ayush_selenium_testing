package Locators;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();	
		
		driver.manage().window().maximize();
		
		driver.get("https://www.saucedemo.com");
		
		// Locate user name by id
	//	driver.findElement(By.id("user-name")).sendKeys("standard_user");
		
		//Locate user name by TagName
		driver.findElement(By.tagName("input")).sendKeys("standard_user");
		
		//Locate pswd by name
		driver.findElement(By.name("password")).sendKeys("secret_sauce");
		
		Thread.sleep(2000);
		
		// click on login button by ClassName
		
		driver.findElement(By.className("submit-button")).click();
		
		// product page window handle new tab me product window item open na ho eske liya ham getwindowhandle method use karte hai.
		String CurrWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(CurrWindowHandle);
		
		// Locate sauce labs bolt T-shirt by linkText
		//driver.findElement(By.linkText("Sauce Labs Bolt T-Shirt")).click();
		
		// Locate sauce labs bolt T-shirt by partiallinkText
		//driver.findElement(By.partialLinkText("Bolt")).click();
		
		// findElemnets method
		List <WebElement> elementList = driver.findElements(By.partialLinkText("Sauce"));
		System.out.println("Element size:" + elementList.size());
		
		
		// closed browser
		
	   driver.quit();
		
		

	}

}
