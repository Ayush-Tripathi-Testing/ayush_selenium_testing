package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Xpath {

	public static void main(String[] args) {
		
WebDriver driver = new ChromeDriver();	
		
		driver.manage().window().maximize();
		
		driver.get("https://www.saucedemo.com");
		
		// Locate user Name by xpath using single attribute
		driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
		
		// Locate PSWD by xpath using multiple attribute
		driver.findElement(By.xpath("//*[@id='password'][@name='password']")).sendKeys("secret_sauce");
		
		// Locate Login Button by xpath
		driver.findElement(By.xpath("//input[@id='login-button']")).click();
		
		//Switch to product page
		String CurrentWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(CurrentWindowHandle);
		
		// And / Or condition using xpath 
		driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-backpack' and @name='add-to-cart-sauce-labs-backpack']")).click(); 
		
		driver.findElement(By.xpath("//button[@id='add-to-cart-sauce-labs-bolt-t-shirt' or @name='add-to-cart-sauce-labs-bolt-t-shirt']")).click();
	}

}
