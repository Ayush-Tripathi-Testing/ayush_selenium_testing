package Locators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CssSelector {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();	
		
		driver.manage().window().maximize();
		
		driver.get("https://www.saucedemo.com");
		
		// Locate user name by tag#id
		driver.findElement(By.cssSelector("input#user-name")).sendKeys("standard_user");
		
		// Locate Pswd by tag[attribute=value]
		driver.findElement(By.cssSelector("input[name=password]")).sendKeys("secret_sauce");
		
		// Locate login Button by tag.value of class name
		driver.findElement(By.cssSelector("input.submit-button")).click();
		
		// Switch window handle
		String CurrentWindowHandle = driver.getWindowHandle();
		driver.switchTo().window(CurrentWindowHandle);
		
		// LOCATE AdddToCart button by tag.valueClass[attribute=value]
		driver.findElement(By.cssSelector("button.btn[name=add-to-cart-sauce-labs-backpack ]")).click();
		
		// Locate by tag[attribute$=substring]
        driver.findElement(By.cssSelector("button[name$=light]")).click();
	}

}
