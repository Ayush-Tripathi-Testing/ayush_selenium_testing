package Cookies;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CookiesExample {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		//Open url
		driver.get("https://www.amazon.in/");

		// 1) Capture all the cookies list
		Set<Cookie> cookiesList =driver.manage().getCookies();

		//print size/number of cookies
		System.out.println("Before adding Size:" + cookiesList.size());

		for(Cookie ck: cookiesList) {

			System.out.println(ck.getName() + ":" + ck.getValue());
		}


		// 2) get specific cookies according to name
		//		i18n-prefs:INR
		//		session-id-time:2082787201l
		//		ubid-acbin:259-0541137-5240909
		//		csm-hit:tb:s-AQSASY0FVD8GNZ60XNAR|1742953014095&t:1742953014823&adb:adblk_no
		//		session-id:260-6218867-5401565

		// System.out.println(driver.manage().getCookieNamed("i18n-prefs"));


		// 3) create cookies
		Cookie cookiesObjt = new Cookie("TestCookie" , "https://www.amazon.in/" );
		driver.manage().addCookie(cookiesObjt);

		cookiesList =driver.manage().getCookies();

		//print size/number of cookies
		System.out.println("\n\nAfter adding Size:" + cookiesList.size());

		for(Cookie ck: cookiesList) {

			System.out.println(ck.getName() + ":" + ck.getValue());
		}

		
		// 4) delete cookie method
		// driver.manage().deleteCookie(cookiesObjt);
		//driver.manage().deleteCookieNamed("TestCookie");
		driver.manage().deleteAllCookies();
		
		cookiesList =driver.manage().getCookies();

		//print size/number of cookies
		System.out.println("\n\nAfter deleting Size:" + cookiesList.size());

		for(Cookie ck: cookiesList) {

			System.out.println(ck.getName() + ":" + ck.getValue());
		}

		driver.quit();

	}

}
