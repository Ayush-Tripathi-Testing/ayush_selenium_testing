package JavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutor {

	public static void main(String[] args) {
		

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// JSExecuto-  this is an interface which helps to execute JavaScript via Selenium WebDriver  by Automation Hub sarthak.
		
		JavascriptExecutor js = (JavascriptExecutor) driver;   //Javascript casting
		js.executeScript("window.location = 'https://gurus.rediff.com/'");
		
		
		//Scrolling page
		js.executeScript("window.scrollBy(0,900)");

	}

}
