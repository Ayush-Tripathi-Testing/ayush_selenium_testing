package DataDrivenTesting;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DataDrivenTestingExample {

	public static void main(String[] args) {


		XSSFWorkbook ExcelWBook =null;
		XSSFSheet ExcelWSheet;
//		XSSFRow Row;
//		XSSFCell Cell;
		
		//Create an object of file class to open file
		File excelFile = new File("C:\\Users\\ayush.tripathi\\new selenium files\\TestDataFile.xlsx");
		FileInputStream inputStream = null;
		//Create an object of FileInputStread to read data from file
		try {
			 inputStream = new FileInputStream(excelFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Excel--> workbook-->Sheet-->row-->cell
		
		//create object of XSSFworkbook to handle xlsx file
		try {
			ExcelWBook = new XSSFWorkbook(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//To access workbook sheet
		ExcelWSheet = ExcelWBook.getSheetAt(0);
		
		//Get total row count
		int lastRow = ExcelWSheet.getLastRowNum() + 1 ;
		int lastCells = ExcelWSheet.getRow(0).getLastCellNum();		
		
		for(int currentRow = 1; currentRow<lastRow ; currentRow++) { // To read row data 
			
			// Launch browser
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			
			driver.get("https://www.saucedemo.com/");
			
			// Enter user name
			driver.findElement(By.id("user-name")).sendKeys(ExcelWSheet.getRow(currentRow).getCell(0).toString());
			
			// Enter password
			driver.findElement(By.id("password")).sendKeys(ExcelWSheet.getRow(currentRow).getCell(1).toString());
			
			// Click Login button
			driver.findElement(By.id("login-button")).click();
			
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
//			for(int currentCell = 0; currentCell<lastCells ; currentCell++) {  // To read cell data
//				
//				System.out.println(ExcelWSheet.getRow(currentRow).getCell(currentCell).toString());
//				System.out.println("\t");
//			}
//			
//			System.out.println();
			
			driver.quit();
		}
		
		
		try {
			ExcelWBook.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
