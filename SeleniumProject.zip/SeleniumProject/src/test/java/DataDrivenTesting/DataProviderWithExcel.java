package DataDrivenTesting;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderWithExcel {

    WebDriver driver;  // Create WebDriver object

    @BeforeMethod
    public void setup() {
        // Initialize WebDriver only once (at the class level)
        driver = new ChromeDriver();
        
        // Open the URL
        driver.get("https://www.google.com/");

        driver.manage().window().maximize();
    }

    @Test(dataProvider = "searchDataProvider")
    public void searchKeyWord(String keyword) {
        WebElement searchbox = driver.findElement(By.name("q"));
        searchbox.sendKeys(keyword);
        searchbox.sendKeys(Keys.ENTER);
    }

    @DataProvider(name = "searchDataProvider")
    public Object[][] searchDataProviderMethod() {
        String fileName = "C:\\Users\\ayush.tripathi\\new selenium files\\SearchData.xlsx";
        Object[][] searchData = getExcelData(fileName, "Sheet1");
        return searchData;
    }

    public String[][] getExcelData(String fileName, String sheetName) {
        // Declare Array
        String[][] data = null;

        // Open file in read mode
        try {
            FileInputStream inputStream = new FileInputStream(fileName);

            // Create XSSFWorkBook Class object for Excel file
            XSSFWorkbook workBook = new XSSFWorkbook(inputStream);
            XSSFSheet excelSheet = workBook.getSheet(sheetName);

            // Get total number of rows
            int ttlRows = excelSheet.getPhysicalNumberOfRows();

            // Get total number of cells in the first row
            int ttlCells = excelSheet.getRow(0).getPhysicalNumberOfCells();
            
            // Initialize the array
            data = new String[ttlRows][ttlCells];

            // Loop through the rows and cells to populate the data array
            for (int currentRow = 0; currentRow < ttlRows; currentRow++) {
                for (int currentCell = 0; currentCell < ttlCells; currentCell++) {
                    data[currentRow][currentCell] = excelSheet.getRow(currentRow).getCell(currentCell).getStringCellValue();
                }
            }

            workBook.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return data;
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
