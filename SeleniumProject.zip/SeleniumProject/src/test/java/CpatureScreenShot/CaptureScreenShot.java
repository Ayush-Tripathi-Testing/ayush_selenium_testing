package CpatureScreenShot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.v131.page.model.Screenshot;

public class CaptureScreenShot {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://practice.expandtesting.com/");
		
//1)		//Full page screen shot capture
 
		//Step-1 convert web driver object to takeScreenShot
//		TakesScreenshot Screenshot = ((TakesScreenshot) driver);
//		
//		//Step-2 call getScreenshotAs method to create image file
//		File src = Screenshot.getScreenshotAs(OutputType.FILE);
//		
//		File dest = new File("C:\\Users\\ayush.tripathi\\new selenium files\\SeleniumProject\\ScreenShot\\fullPage.png");
//		
//		//Step-3 copy image file to destination
//		FileUtils.copyFile(src, dest);
		
		
//2)		//Capture particular area screnShot of a web page
		//Step-1 convert web driver object to TakeScreenshot interface
		//WebElement section = driver.findElement(By.xpath("//div[@id='home-header']"));
		
		
		//Step-2 call getScreenshotAs method to create image file
		//File src = section.getScreenshotAs(OutputType.FILE);
		
		
		//File dest = new File("C:\\Users\\ayush.tripathi\\new selenium files\\SeleniumProject\\ScreenShot\\section.png");
		
		
		//Step-3 copy image file to destination
	    //FileUtils.copyFile(src, dest);
		
	    
//3)    //Step-1 particular webElement ScreenShot capture of a web page
	    WebElement WbELementsection = driver.findElement(By.xpath("//a[@class='btn btn-warning py-sm-2 px-sm-3 rounded-pill me-3']")); 
	    
	    //Step-2 call getScreenshotAs method to create image file
	  		File src = WbELementsection.getScreenshotAs(OutputType.FILE);
	  		
	  		File dest = new File("C:\\Users\\ayush.tripathi\\new selenium files\\SeleniumProject\\ScreenShot\\WbELementsection.png");
	  		
	  	//Step-3 copy image file to destination
		    FileUtils.copyFile(src, dest);
	}

}
