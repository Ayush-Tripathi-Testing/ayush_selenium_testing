package ToolTip;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ToolTip {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://training.rcvacademy.com/test-automation-practice-page");
		
		// Find web element age input box
	String actualTooltip = driver.findElement(By.xpath("//input[@id='age']")).getAttribute("title");
	String expectedTooltip = "We ask for your age only for statistical purposes.";
	
	if(actualTooltip.equals(expectedTooltip))
	{
		System.out.println("Test Passed");
	}
	else {
		System.out.println("Test Failed");
	}

	}

}
