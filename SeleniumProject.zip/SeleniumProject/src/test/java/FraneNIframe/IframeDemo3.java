package FraneNIframe;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IframeDemo3 {
	
public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
//		
//        driver.get("https://docs.oracle.com/javase/8/docs/api/");
//		
//		//Switch to iframe
//		driver.switchTo().frame("classFrame");
//		
//		//Find web element
//		driver.findElement(By.linkText("Description")).click();
		
		driver.get("https://blogpendingtasks.blogspot.com/p/switchofframeusingwebelement.html");
		
		WebElement frameWebement = driver.findElement(By.xpath("//iframe[@title='arunmotoori']"));

				driver.switchTo().frame("frameWebement");
				
				driver.findElement(By.linkText("Home")).click();
				
}
}