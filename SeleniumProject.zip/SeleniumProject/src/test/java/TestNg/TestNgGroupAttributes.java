package TestNg;

import org.testng.annotations.*;

public class TestNgGroupAttributes {
	
	    @Test(groups="Software Company")
		public void Infosys()
		{
		  System.out.println("Infosys.!");
		}
		
	    @Test(groups="Software Company")
		public void Wipro()
		{
		  System.out.println("Wipro.!");
		}
		
	    @Test(groups="AutoMobile Company")
		public void Tata()
		{
		  System.out.println("Tata.!");
		}
	
	    @Test(groups="AutoMobile Company")
		public void Maruti()
		{
		  System.out.println("Maruti.!");
		}

}
