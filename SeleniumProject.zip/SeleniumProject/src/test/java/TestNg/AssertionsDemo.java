package TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class AssertionsDemo {

	@Test
	public void testMethod(){

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		SoftAssert softVerify = new SoftAssert();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		System.out.println("verifying title....");
		String expectedTitle = "Automation Testing Practice1";
		String actualTitle = driver.getTitle();
	//  Assert.assertEquals(expectedTitle, actualTitle , "Title verifying");  //---Hard Assertion method
		softVerify.assertEquals(expectedTitle, actualTitle, "Title verification failed");  //--SoftAssert method
		
		System.out.println("Verifying presence of wikipedia-icon");
        WebElement icon=  driver.findElement(By.className("wikipedia-icon"));
     // Assert.assertTrue(icon.isDisplayed());  //---HardAssertion method
        softVerify.assertTrue(icon.isDisplayed());    //---SoftAssertion method
        
        System.out.println("Verifying presence of wikipedia-search-button");
        WebElement SearchBtn=  driver.findElement(By.className("wikipedia-search-button"));
     // Assert.assertTrue(SearchBtn.isDisplayed());  //--HardAssertion method
        softVerify.assertTrue(SearchBtn.isDisplayed());  //--SoftAssertion method
        
        driver.close();
        
        //Report all failure method ("Important point ,if the below method is not called, this test case is passed and when the below method is called, this test case is failed").
        softVerify.assertAll();
	}

}
