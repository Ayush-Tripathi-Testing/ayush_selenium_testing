package TestNg;

import org.testng.ITestContext;
import org.testng.annotations.Test;

import ch.qos.logback.core.Context;

public class InvocationCount {
	
	@Test(invocationCount =5)
	public void testMethod1(ITestContext Context) {
		int CurrentInvocation = Context.getAllTestMethods()[0].getCurrentInvocationCount();
		System.out.println("Executing:" + CurrentInvocation);
		System.out.println("Test method1.....");
		
	}

	@Test(invocationCount =3)
	public void testMethod2(ITestContext Context) {
		int CurrentInvocation = Context.getAllTestMethods()[1].getCurrentInvocationCount();
		System.out.println("Executing:" + CurrentInvocation);
		System.out.println("Test method2.....");
		
	}

}
