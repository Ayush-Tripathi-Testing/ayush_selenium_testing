	package TestNg;

	import org.eclipse.mylyn.builds.core.ITestResult;
	import org.testng.ITestContext;
	import org.testng.ITestListener;
	import org.testng.annotations.*;

	public class TestNgListenerClass {
		
		public class ListenerClass implements ITestListener{
	}
		

			public void onStart(ITestContext Result) {	

				System.out.println("on start method of invoked..!");
			}

			public void onFinish(ITestContext Result) {

				System.out.println("Name of test method failed..!");
			}
			
			public void onTestFailure(ITestResult Result) {

				System.out.println("Name of test method failed:" + ((ITestContext) Result).getName());
		}
			
			
			public void onTestSkipped(ITestResult Result) {

				System.out.println("Name of test method Skipped:" + ((ITestContext) Result).getName());
		}
			
			public void onTestStart(ITestResult Result) {

				System.out.println("Name of test method started:" + ((ITestContext) Result).getName());
		}
			
			public void onTestSuccess(ITestResult Result) {

				System.out.println("Name of test method sucessfully executed:" + ((ITestContext) Result).getName() );
	}
			
			public void onTestFailedButWithSuccessPercentage(ITestResult Result) {

				//System.out.println("Name of test method started.!");
		}
}
