package TestNg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestNgDemo {
	
	@Test
	public void verifyPageTitle() {
		
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	driver.get("http://www.google.com");
	String expecteditle ="Google";
	String actualTitle = driver.getTitle();
	
	Assert.assertEquals(actualTitle, expecteditle);

	driver.quit();
}
	
}