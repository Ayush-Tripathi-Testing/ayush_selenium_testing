package TestNg;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
imort org.testng.annotation.ITestAnnotation;
import org.testng.annotations.IAnnotation;

public class RetryListner Implements IAnnotationTransformer {

	public void transform(IAnnotation testAnnotation , class testClass) { 
		Constructor testConstructor, Method testMethod){
	}
			
		}
	}
	
}