package TestNg;

import org.testng.annotations.*;

public class TestNgAnnotations {
	
	@BeforeSuite
	public void BeforeSuite()
	{
		System.out.println("Before suite....");
	}
	
	@AfterSuite
	public void AfterSuite()
	{
		System.out.println("After suite....");
	}
	
	@BeforeTest
	public void BeforeTest()
	{
		System.out.println("Before test....");
	}
	
	@AfterTest
	public void AfterTest()
	{
		System.out.println("After test....");
	}
	
	@BeforeClass
	public void BeforeClass()
	{
		System.out.println("Before class....");
	}
	
	@AfterClass
	public void AfterClass()
	{
		System.out.println("After class....");
	}
	
    @BeforeMethod
	public void BeforeMethod()
	{
		System.out.println("Before method....");
	}
	
    @AfterMethod
    public void AfterMethod()
	{
		System.out.println("After method....\n");
	}
	@Test
	public void Testcase1()
	{
		System.out.println("This is Test1....");
	}
	
	@Test
	public void Testcase2()
	{
		System.out.println("This is Test2....");
	}

}
