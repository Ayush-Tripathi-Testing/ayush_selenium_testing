package TestNg;

import org.testng.annotations.Test;

public class TestNgXml {
	
	@Test
	public class  TestNgExample {
	
		@Test
		public void test1() {
			
			System.out.println("Test Case1");
		}
		
		@Test
		
		
		public void test2(){
			
			System.out.println("Test case2");
			
			
		}
		
	}

}
