package TestNg;

import org.testng.annotations.*;

public class TestNgAnnotations2 {

	
	@Test
	public void Testcase3()
	{
		System.out.println("This is Test3....");
	}
	
	@Test
	public void Testcase4()
	{
		System.out.println("This is Test4....");
	}

}

