package TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class TestNgDataProvider {
	
	//1. India Qutub minar
	//2. Agra Taj mahal
	//3. Hyderabad Charminar
	
//	@DataProvider(name = "searchDataSet")
//	public Object[][] searchData()
//	{
//		Object[][] searchKeyword = new Object[3][2];
//		searchKeyword[0][0] = "India";
//		searchKeyword[0][1] = "Qutub minar";
//		
//		searchKeyword[1][0] = "Agra";
//		searchKeyword[1][1] = "Taj mahal";
//		
//		searchKeyword[2][0] = "Hyderabad";
//		searchKeyword[2][1] = "Charminar";
//		
//		return searchKeyword;
//	}
	
    @Test(dataProvider = "searchDataSet", dataProviderClass = TestNgDataProviderMethod.class)
	public void TestCaseGoogleSearch(String country , String monument ){
		
	
	WebDriver driver = new ChromeDriver();	
	driver.manage().window().maximize();

	driver.get("https://www.google.com/");
	
	WebElement searchbox =driver.findElement(By.name("q"));
	searchbox.sendKeys(country + " " + monument );
	
	driver.findElement(By.name("btnK")).submit();
	

}

}