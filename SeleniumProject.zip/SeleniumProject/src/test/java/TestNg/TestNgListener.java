package TestNg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestListener;
import org.testng.SkipException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

  @Listeners(TestNg.TestNgListenerClass.class)
public class TestNgListener { 

	@Test
	public void login() {
		
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[normalize-space()='Login']")).submit();
		
		Assert.assertEquals(driver.getTitle(), "OrangeHRM");
		
	}
	
	@Test
	public void testfail(){
		System.out.println("Failed test case..!");
		Assert.assertTrue(false);
		}
	
	
	@Test
	public void testskiped(){
		System.out.println("Skipped test case..!");
		throw new SkipException("skip exception thrown..!");
		
		}
}


