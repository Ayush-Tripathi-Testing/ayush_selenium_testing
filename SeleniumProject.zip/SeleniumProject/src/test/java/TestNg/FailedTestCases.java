package TestNg;

import org.testng.Assert;
import org.testng.annotations.*;

public class FailedTestCases {
	
	public class TestCasesExample{
		
		@Test(retryAnalyzer = RetryAnalyser.class)
		public void TestCase01() {
			Assert.assertTrue(false);  // Test Case will fail
		}
		
		@Test(retryAnalyzer = RetryAnalyser.class)
		public void TestCase02() {
			Assert.assertTrue(false);  // Test Case will fail
		}
		
		@Test
		public void TestCase03() {
			Assert.assertTrue(true);  // Test Case will pass
		}
	}

}
