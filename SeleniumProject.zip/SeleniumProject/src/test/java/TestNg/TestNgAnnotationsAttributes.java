package TestNg;

import org.testng.Assert;
import org.testng.annotations.*;

public class TestNgAnnotationsAttributes {

	//@Test(description ="This is testcase1.")
	@Test(enabled= false)
	//@Test//(dependsOnMethods= {"TestCase3","TestCase2"})
	//@Test(priority=1)
	//@Test(timeOut =200)
	public void TestCase1()
	{
		try {
			Thread.sleep(400);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	  System.out.println("Mobile login TestCase..!");
	}
	
	@Test
	//@Test(priority=2)
	//@Test(description ="This is testcase2.")
	public void TestCase2()
	{
	  System.out.println("Web login TestCase..!");
	}
	
	@Test//(description ="This is testcase3.")
	public void TestCase3()
	{
	  System.out.println("Api login TestCase..!");
	 // Assert.assertTrue(false);
	}
}


