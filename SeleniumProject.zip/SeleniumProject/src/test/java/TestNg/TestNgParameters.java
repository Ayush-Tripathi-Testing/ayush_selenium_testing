package TestNg;

import org.testng.annotations.Parameters;
import org.testng.annotations.*;

public class TestNgParameters {
	
	@Test
	@Parameters({"i", "j"})
	public void add(int a, int b) {
		System.out.println("Add:" + (a+b));
	}
	
	
	@Test
	@Parameters({"i", "j"})
	public void substraction(int a, int b) {
		System.out.println("Subs:" + (a-b));
	}
	
	
	@Test
	@Parameters({"i", "j"})
	public void multiply(int a, int b) {
		System.out.println("Mul:" + (a*b));
	}
	

}
