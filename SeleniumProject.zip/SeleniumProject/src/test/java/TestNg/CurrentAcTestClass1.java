package TestNg;

import org.testng.annotations.*;

public class CurrentAcTestClass1 {
	
	@Test
	public void test1()
	{
		System.out.println("Current A/C test case1");
	}

	@Test
	public void test2()
	{
		System.out.println("Current A/C test case2");
	
	}
	


}

