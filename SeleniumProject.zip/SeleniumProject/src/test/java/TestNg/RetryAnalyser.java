
package TestNg;

import org.eclipse.mylyn.builds.core.ITestResult;
import org.testng.IRetryAnalyzer;

public class RetryAnalyser implements IRetryAnalyzer {

	//Counter to keep track of retry attempts
	
	int CounterForRetryAttempts =0;
	
	// Set max limit for retry
	int setMaxLimitForRetry = 3;
	
	public boolean retry(ITestResult result) {
		return false;
		
	}

	@Override
	public boolean retry(org.testng.ITestResult result) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}
