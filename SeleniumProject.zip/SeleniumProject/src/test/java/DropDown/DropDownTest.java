package DropDown;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownTest {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.udyog-aadhar.com/#msme-registration");
		
		// locate drop down
		WebElement element = driver.findElement(By.name("LEADCF9"));
		Select dropdown = new Select(element);
		
		// Locate drop down elements by selectByVisibletext();
		//dropdown.selectByVisibleText("SC");
		
		//Locate drop down elements by selectByValue();
		//dropdown.selectByValue("OBC");
		
		//Locate drop down elements by selectByIndex();
		//dropdown.selectByIndex(4);
		
		//Locate drop down elements by .isMultiple()
		if(dropdown.isMultiple())
		{
			System.out.println("Drop down is multiple");
			
		}else {
			
			System.out.println("Drop down is not multiple");
		}
		
		// Locate all select option by List variable elements
		List <WebElement> alldropdownoptions = dropdown.getOptions();
		
		System.out.println("Total Option : " + alldropdownoptions.size());
		for(WebElement el :alldropdownoptions)
		{
			System.out.println(el.getText());
		}
		
		driver.close();
	}

}
