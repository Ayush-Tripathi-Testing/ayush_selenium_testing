package HyperLinks;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HyperLinksTest {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.calculator.net/");
		
		//Locate all hyperlinks in webpage by findEelements method  imp topic for interview.
		List <WebElement> linkElements = driver.findElements(By.tagName("a"));
		
		System.out.println("Total links on Webpage: " + linkElements.size());
		
		for(WebElement el:linkElements)
		{
			System.out.println(el.getText());
		}
		
		driver.close();

	}

}
