package EncodePassword;

import org.apache.hc.client5.http.utils.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class EncodePasswordExample {

	public static void main(String[] args) {
		
//		String password = "admin123";
//		
//		byte[] encodePassword = Base64.encodeBase64(password.getBytes());
//		
//		System.out.println(new String (encodePassword));    //YWRtaW4xMjM=

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		
		byte[] decodedPassword = Base64.decodeBase64("YWRtaW4xMjM=");   
		
	    driver.findElement(By.id("txtPassword")).sendKeys(new String(decodedPassword));
	    
	    driver.findElement(By.id("btnLogin")).click();
	    
	    driver.quit();
		
	}

}
