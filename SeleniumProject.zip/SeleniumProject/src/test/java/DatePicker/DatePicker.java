package DatePicker;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DatePicker {

	public static void main(String[] args) {
	
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://jqueryui.com/datepicker/");
		
		driver.switchTo().frame(0);
		
		driver.findElement(By.id("datepicker")).click();


		//22/11/2000
		
		while(true)
		{
			String month= driver.findElement(By.xpath("//span[@class='ui-datepicker-month']")).getText();
			String year= driver.findElement(By.xpath("//span[@class='ui-datepicker-year']")).getText();
			
			if(year.equals("2000") && month.equals("November")){
				driver.findElement(By.xpath("//a[normalize-space()='22']")).click();
				break;
			
			}else {
				driver.findElement(By.xpath("//span[@class='ui-icon ui-icon-circle-triangle-w']")).click();
			}
		}
		
	}

}
