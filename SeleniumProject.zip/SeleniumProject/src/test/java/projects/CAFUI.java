package projects;


import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CAFUI {

    public static void main(String[] args) throws InterruptedException {
        // Setup ChromeDriver
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Open the URL
        driver.get("https://bpmentsitapp.jio.com/Runtime/Runtime/Form/CAFHome/?&userid=IN%5CAyush.Tripathi");

        // Wait for the page to load
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Click the details button and proceed
        try {
            WebElement detailsButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("details-button")));
            detailsButton.click();

            WebElement proceedLink = wait.until(ExpectedConditions.elementToBeClickable(By.id("proceed-link")));
            proceedLink.click();
        } catch (Exception e) {
           
        }

        // Wait for the element with the specified XPath to be clickable and then click it
       // try {
            WebElement imageElement = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[@id='5267e1fe-d208-5b30-e967-f20fec46ecc0']")));
            imageElement.click();  // Use click instead of submit, as it's a clickable element
//        } catch (Exception e) {
//            
//        }

        // Wait for the next element (another image) and click it
        try {
            WebElement secondImageElement = wait.until(ExpectedConditions.elementToBeClickable(By.id("997a2f24-b04a-a18e-7b21-53152d76b81d_36fd1f08-4619-0efc-8ab6-589760afde9e_Picture")));
            secondImageElement.click();  // Again, click instead of submit
        } catch (Exception e) {
           
        }
       
        Thread.sleep(3000);
        try {
        WebElement iframe = driver.findElement(By.className("runtime-popup"));
        driver.switchTo().frame(iframe);
        } catch (Exception e) {
        	
        }
//			 driver.switchTo().frame("#PopupWin_1744100140604 > div.popup-body > div.popup-body-c > div > div > iframe");
		
        // Wait for and interact with the radio button (Individual Approval)
        try {
        	//Thread.sleep(2000);
            WebElement radioButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Individual Approval']")));
            radioButton.click();  // Click the radio button once it's clickable
            System.out.println("Radio button clicked successfully.");
        } catch (Exception e) {
            System.out.println("Error interacting with radio button: " + e.getMessage());

            
        Thread.sleep(3000);
//            try {
//            WebElement iframe = driver.findElement(By.className("runtime-popup"));
//            driver.switchTo().frame(iframe);
//            } catch (Exception e1) {
//            	
//           }
            
            try {
            WebElement element  = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@title='ORN']")));
            element.click();
    		Select dropdown = new Select(element);
    		//Select select = new Select(null);
			dropdown.selectByValue("1");
			
            } catch (Exception e2) {
            	
            }
    		
    		
           driver.quit();  // Close the driver after the actions
        }
    }
}
