package projects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Jio {

    public static void main(String[] args) throws InterruptedException {

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        // Open the URL
        driver.get("https://sit.webselfcare.jio.com/selfcare/login/");

        driver.findElement(By.xpath("//div[contains(text(),'JioFiber')]")).click();

        driver.findElement(By.id("inputField")).sendKeys("716180007335");

        driver.findElement(By.xpath("//button[@aria-label='button Generate OTP']")).click();

        // Wait for the OTP input field to be visible
        WebElement otpField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("otp-input-field")));
        System.out.println("OTP input field is visible. Please enter the OTP manually.");
        
        

        // Wait for the user to enter OTP manually
        while (true) {
        	Thread.sleep(3000);
            String otpValue = otpField.getAttribute("value");
            if (!otpValue.isEmpty()) {
                System.out.println("OTP entered: " + otpValue);
                break;
            }
            System.out.println("Waiting for OTP input...");
            try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
//				e.printStackTrace();
			} // Wait for 3 seconds before checking again
        }
        
        try {
        	Thread.sleep(3000);
        	WebElement submitButton =driver.findElement(By.xpath("//button[contains(text(),'Submit')]"));
        	submitButton.sendKeys(Keys.ENTER);
//        	  JavascriptExecutor js = (JavascriptExecutor) driver;
//              js.executeScript("arguments[0].click();", submitButton);
        }catch (Exception e){
        	
        }

        // Locate the submit button
        
        //submitButton.sendKeys(Keys.ENTER);
        
        // Click the submit button using JavaScript if it's not clickable
      

        // Optional: Wait for successful login (check for an element that only appears after login)
//        try {
//            WebElement loggedInElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='logged-in-home-page-element']")));
//            System.out.println("Logged in successfully!");
//        } catch (Exception e) {
//            System.out.println("Login failed: " + e.getMessage());
//        }

        // Close the browser
        driver.quit();
    }

	        
	      //  driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/section[2]/section/section[2]/div/section/section/div[2]/button")).click();
	        
	        
	        
	        
	}


