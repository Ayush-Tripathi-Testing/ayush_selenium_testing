package projects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JPWPO {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://jpw-sit.jio.com/v1/?root=SplashScreen&version=2.0.4&deviceId=359906080728855&isFirstTimeLaunch=true");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		// Wait for "btn_return" to be clickable and then click
		WebElement returnButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("btn_return")));
		returnButton.click();

		// Enter mobile number
		WebElement mobileInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("mob_no")));
		mobileInput.sendKeys("9800020084");

		// Click 'Get OTP' button
		WebElement getOtpButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("getOtp")));
		getOtpButton.click();

		// Wait for OTP input to be visible and enter OTP
		WebElement otpInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='0']")));
		otpInput.sendKeys("111111");

		// Click 'Verify OTP' button
		WebElement verifyOtpButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='button Verify OTP']")));
		verifyOtpButton.click();

		// Wait for post-login actions (e.g., onboarding)
		WebElement onboardButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/button")));
		onboardButton.click();

		// Wait for email input and enter email
		WebElement emailInput = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email")));
		emailInput.sendKeys("asd@gmail.com");

		// Wait and click 'Send OTP' button
		WebElement sendOtpButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Send OTP']")));
		sendOtpButton.click();

		// Wait and click 'OK' after OTP is sent
		WebElement okButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='OK']")));
		okButton.click();

		// Wait for OTP input and enter OTP
		WebElement otpInput2 = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-testid='tf_otp']//input[@type='text']")));
		otpInput2.sendKeys("123456");

		// Wait and click 'Validate OTP' button
		WebElement validateOtpButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Validate OTP']")));
		validateOtpButton.click();

		// Wait and click the next button after OTP validation
		WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/div[4]/div/div[1]/div/div/div[2]/div/input")));
		nextButton.click();

		// Click the final step button
		WebElement finalStepButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(@class,'step_box_inner w-100 text-left')]")));
		finalStepButton.click();

		// click on profile details

		//  WebElement profileDetails = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[4]/div/ul/li[1]/button")));
		driver.findElement(By.cssSelector(".step_box_inner.w-100.text-left")).click();

		
		driver.findElement(By.xpath("//li[@class='steps_three cursor_pointer']")).click();


		driver.findElement(By.cssSelector("li[class='steps_three cursor_pointer']")).click();


		// Quit the driver
		driver.quit();
	}
}



