package projects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JPWPartnerOnboard {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://jpw-sit.jio.com/v1/?root=SplashScreen&version=2.0.4&deviceId=359906080728855&isFirstTimeLaunch=true");
		
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.id("btn_return")).click();
		
		driver.findElement(By.id("mob_no")).sendKeys("9800079011");
		
		driver.findElement(By.id("getOtp")).click();
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.xpath("//input[@placeholder='0']")).sendKeys("111111");
		
		driver.findElement(By.xpath("//button[@aria-label='button Verify OTP']")).click();
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		//after login JPW
		
		//driver.findElement(By.xpath("//div[contains(text(),'Onboard as Organization')]")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div[1]/button")).click();
		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.id("email")).sendKeys("asd@gmail.com");
//		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.xpath("//input[@value='Send OTP']")).click();
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.xpath("//input[@value='OK']")).click();
		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.xpath("//div[@data-testid='tf_otp']//input[@type='text']")).sendKeys("123456");
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		driver.findElement(By.xpath("//input[@value='Validate OTP']")).click();
		
		//driver.findElement(By.xpath("//input[@value='OK']")).click();
		driver.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div[2]/div/input")).click();
		
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		driver.findElement(By.xpath("//button[contains(@class,'step_box_inner w-100 text-left')]")).click();
		
		driver.quit();

	}

}
