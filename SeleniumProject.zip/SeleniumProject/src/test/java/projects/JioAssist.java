package projects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JioAssist {

    /**
     * @param args
     * @throws InterruptedException
     */
    /**
     * @param args
     * @throws InterruptedException
     */
    public static void main(String[] args) throws InterruptedException {
        // Initialize the WebDriver
        WebDriver driver = new ChromeDriver();
        driver.get("https://jioassist.mobility.sit.jio.com/");
        driver.manage().window().maximize();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));

      //  try {
            // Wait for username field and enter the username
            WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
            usernameField.sendKeys("Ayush.Tripathi");

            // Wait for password field and enter the password
            WebElement passwordField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("password")));
            passwordField.sendKeys("Shyam@11");

            // Wait for login button and click it
            WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@value='Login']")));
            loginButton.click();

            // Wait for the next button to become clickable and click it
            WebElement clickButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='button']")));
            clickButton.click();

            // Wait for the search field to be visible and click on it
            WebElement searchdata = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Search']")));
            searchdata.click();

            // Search for the JioAssist number
            WebElement searchJioAssist = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@placeholder='Search JioAssist']")));
            searchJioAssist.sendKeys("716180041474");
            searchJioAssist.sendKeys(Keys.ENTER);

            // Wait for the element and scroll it into view
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"main-content\"]/div[1]/div[2]/div[2]/div/div[5]/div/div[2]/div[1]/div/div")));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].scrollIntoView();", element);

            // Wait for interaction button and click it
            WebElement clickableInteraction = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html[1]/body[1]/div[1]/section[1]/section[1]/section[2]/div[1]/div[2]/div[2]/div[1]/div[5]/div[1]/div[2]/div[2]/div[1]")));
            clickableInteraction.click();

            // Wait for and click the next button
            WebElement nextButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"main-content\"]/section[2]/div[2]/div[3]/button")));
            nextButton.click();

            // Wait for and click the last button
            WebElement lastButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@data-rsbs-scroll='true']//div[2]//button[1]")));
            lastButton.click();

            // Wait for the smart tag field and send keys
            WebElement sendsSmartTag = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("smartTagCode")));
            sendsSmartTag.sendKeys("C1213");
            sendsSmartTag.sendKeys(Keys.ENTER);
            
            Thread.sleep(5000);

            // Wait for and click the appointment date picker
            WebElement dateField = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Select Appointment Date']")));
            dateField.click();
            
            //click on Appointment slot
//            WebElement slot = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[normalize-space()='Apr 10, 2025; 20:00']")));
//            slot.click();

//            List<WebElement> timeSlots = driver.findElements(By.xpath("//div[normalize-space()='Jun 23, 2025; 10:00']"));
//
//            for (WebElement slot : timeSlots) {
//                if (slot.isEnabled()) {  // or !slot.getAttribute("class").contains("disabled")
//                    slot.click();  // select first available
//                    
//                }
//            }
            
            WebElement dropdown = driver.findElement(By.className("ja-pointer j-container"));
            Select select = new Select(dropdown);
            select.selectByVisibleText("Jun 23, 2025; 10:00");
            
            //submit button
            WebElement submitbutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='button Submit']")));
            submitbutton.click();
            
            //Save button
            WebElement savebutton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@aria-label='button Save']")));
            savebutton.click();
       // } catch (Exception e) {
//            // Catch and print any exceptions that occur
        //    System.out.println("Error during execution: " + e.getMessage());
//        } finally {
//            // Close the browser session after completion (optional)
//            driver.quit();
       // }
    }
}
