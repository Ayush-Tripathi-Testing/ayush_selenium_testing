package AlertNPopups;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsNpopups {

	public static void main(String[] args) throws InterruptedException {


		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("http://uitestingplayground.com/alerts");
		
		//Find alert button and perform click action
		//driver.findElement(By.xpath("//button[@id='alertButton']")).click();
		
		//driver.findElement(By.xpath("//button[@id='confirmButton']")).click();  // find confirmed button and performed click action
		
		driver.findElement(By.xpath("//button[@id='promptButton']")).click();     //find prompt button and performed click action
		
		// Switch to alert window and accept the alert
		//driver.switchTo().alert().accept(); // ok button is clicked
		
		//driver.switchTo().alert().dismiss();  // cancel button is clicked
		
		driver.switchTo().alert().sendKeys("Ayush"); // switch to alert window and enter the value/name
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();    // to accept OK alert button
		
		
		

	}

}
