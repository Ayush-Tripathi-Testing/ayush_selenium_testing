package SyncronisationIssueWaits;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import com.google.common.base.Stopwatch;

public class FluentWait {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://export.ebay.com/in/");
		
		//Fluent wait of 10 seconds
	   Wait<WebDriver> wait = new org.openqa.selenium.support.ui.FluentWait<WebDriver>(driver)
			   .withTimeout(Duration.ofSeconds(10))
		       .pollingEvery(Duration.ofSeconds(2))	
		       .withMessage("this is custom message. ")
		       .ignoring(NoSuchElementException.class);
	   
       driver.findElement(By.xpath("//*[@id=\"onetrust-reject-all-handler\"]")).click();
	   
	   WebElement element =wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Start Selling")));
		element.click();
	   
//	    Stopwatch watch = null;
//	    
//		try {
//			watch = Stopwatch.createStarted();
//			
//			
//			
//			//Find element "Start Selling"
//			
//		}
//		catch(Exception e)
//		{
//		 
//			watch.stop();
//			System.out.println(e);
//			System.out.println(watch.elapsed(TimeUnit.SECONDS) + "seconds");
//		}
//
	}

}
