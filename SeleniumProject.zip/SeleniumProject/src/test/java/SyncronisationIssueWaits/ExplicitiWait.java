package SyncronisationIssueWaits;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Stopwatch;

public class ExplicitiWait {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://export.ebay.com/in/");
		
		//Expliciti wait of 10 seconds
	    WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));  // ess wait me  exception aane se phle 10 second tak wait karega. 
				
	    Stopwatch watch = null;
	    
		try {
			watch = Stopwatch.createStarted();
			
			driver.findElement(By.xpath("//*[@id=\"onetrust-reject-all-handler\"]")).click();
			
			//Find element "Start Selling"
			WebElement element =wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Start Selling")));
			element.click();
		}
		catch(Exception e)
		{
		 
			watch.stop();
			System.out.println(e);
			System.out.println(watch.elapsed(TimeUnit.SECONDS) + "seconds");
		}

	}

}
