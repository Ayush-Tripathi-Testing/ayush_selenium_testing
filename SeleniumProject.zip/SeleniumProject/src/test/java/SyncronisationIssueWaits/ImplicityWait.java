package SyncronisationIssueWaits;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.base.Stopwatch;

public class ImplicityWait {

	public static void main(String[] args) {


		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://export.ebay.com/in/");
		
		//wait of 10 seconds
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));    // all web element me apply hota hai ( impliciti wait global wait hota h)
		Stopwatch watch = null;
		
		try {
			watch = Stopwatch.createStarted();
			
			driver.findElement(By.xpath("//*[@id=\"onetrust-reject-all-handler\"]")).click();
			
			//Find element "Start Selling"
			driver.findElement(By.linkText("Start Selling")).click();
		}
		catch(Exception e)
		{
		 
			watch.stop();
			System.out.println(e);
			System.out.println(watch.elapsed(TimeUnit.SECONDS) + "seconds");
		}
		

	}

}
